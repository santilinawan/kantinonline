# Njajan
Njajan adalah aplikasi yang memudahkan mahasiswa dalam melakukan pemesanan makanan dan minuman secara online di area kampus.
